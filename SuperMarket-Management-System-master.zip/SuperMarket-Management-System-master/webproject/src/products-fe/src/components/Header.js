import React, { Component } from "react";

class Header extends Component {
  render() {
    return (
      
      <div className="text-center"   >
        <h1>SuperMarket Management System </h1>
        <h3>Stocks (Using React and Django)</h3>
        <hr />
      </div>
    );
  }
}

export default Header;